<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
      </div>
      <strong>Copyright &copy; 2023 Brought to You By <a href="#/">KENT</a></strong>
    </div>
</footer>